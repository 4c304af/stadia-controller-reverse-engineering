"""The receiver: the HTTP front door for every controller, and the registry of their sessions.

The :class:`Receiver` owns what is shared: the HTTPS/HTTP listeners, the helper processes (DNS
sink, SNTP), the clock and the log.  Everything a controller does is routed to its own
:class:`~stadiacast.controller.ControllerSession`, created the first time the controller
identifies itself.  Requests are attributed to a controller by, in order: the GMsg
``subscription`` token (our per-controller display token, echoed by the firmware), the
``controller-cloud-device-id`` / ``controller-device-id`` headers or the ``device_id`` in the
request body, and finally the peer address.

``docs/protocol.md`` describes the protocol itself and what is confirmed versus assumed.
"""

from __future__ import annotations

import asyncio
import datetime
import html
import json
import os
import re
import socket
import sys
import time
import traceback
from typing import Any
from urllib.parse import parse_qs

from google.protobuf import json_format
from google.protobuf.message import DecodeError

from stadiacast import SERVER_NAME, __version__
from stadiacast.audio import ffmpeg_path, source_from_spec
from stadiacast.certs import ensure_certificate, resolve_clock_pin
from stadiacast.config import CLEARCUT_HOSTS, Config
from stadiacast.controller import ControllerSession
from stadiacast.errors import SetupError
from stadiacast.helpers import DNS_SINK, SNTP_SERVER, helper_command
from stadiacast.http_server import HttpRequest, HttpResponse, HttpServer
from stadiacast.log import EventLog
from stadiacast.micdevice import MicrophoneDevice, open_output
from stadiacast.netutil import bind_hint, fetch_upstream, is_loopback, local_ip_towards
from stadiacast.protos import Protos, decode_unknown, printable
from stadiacast.virtual_gamepad import VirtualGamepads

#: Sessions kept at once; beyond this the least recently seen controller is forgotten.
MAX_CONTROLLERS = 8
#: Decoded input events kept for :meth:`Receiver.wait_event`; the oldest go first.
EVENTS_KEPT = 1000
#: How much of a request body is decoded into its ``http_request`` record; the whole body is in
#: the run directory.  The controller's bodies are a few KiB.
LOGGED_BODY_BYTES = 16 * 1024
#: How much of an Omaha request is searched for its apps (a real one is under 2 KiB), and how
#: many of them are answered.
OMAHA_REQUEST_BYTES = 16 * 1024
OMAHA_APPS = 16
#: ``/_events`` streams open at once; one more is refused.
MAX_EVENT_STREAMS = 8
#: Seconds after which an ``/_events`` stream sends the live state again although nothing in it
#: changed: the ages in it stay current, and a client that has gone is found out.
EVENTS_HEARTBEAT = 2.0
#: Seconds an ``/_events`` stream lets pass after a change before it sends, so that the changes
#: of a moving stick, which come faster than a view shows them, share one event.
EVENTS_MIN_GAP = 1 / 60

RPC_PATH = re.compile(r"^/v1:([A-Za-z0-9_]+)$")


def _tail(path: str, lines: int = 5) -> list[str]:
    """The last non-empty lines of a text file: what a helper wrote before it exited."""
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            f.seek(max(0, f.tell() - 4096))
            text = f.read().decode("utf-8", "replace")
    except OSError:
        return []
    return [line.strip() for line in text.splitlines() if line.strip()][-lines:]


class LiveStream:
    """One ``/_events`` client: the live state (:meth:`Receiver.live_state`) as server-sent events.

    The first event goes out at once, the next whenever something in the state changes or
    ``EVENTS_HEARTBEAT`` seconds have passed, and the stream ends when the receiver stops.
    """

    def __init__(self, receiver: Receiver) -> None:
        self.rx = receiver
        self.changed = asyncio.Event()  # set by Receiver.live_changed
        self._begun = False

    async def next_chunk(self) -> bytes | None:
        head = b""
        if not self._begun:
            self._begun = True
            head = b"retry: 1000\n\n"  # how long a browser waits before it connects again
        else:
            try:
                await asyncio.wait_for(self.changed.wait(), EVENTS_HEARTBEAT)
            except TimeoutError:
                pass
            else:
                await asyncio.sleep(EVENTS_MIN_GAP)
        if self.rx.stopping:
            return None
        self.changed.clear()
        return head + b"event: input\ndata: " + json.dumps(self.rx.live_state(), default=str).encode() + b"\n\n"

    def close(self) -> None:
        self.rx.event_streams.discard(self)


class Receiver:
    """The LAN-side stand-in for the Stadia cloud."""

    def __init__(self, cfg: Config, log: EventLog | None = None) -> None:
        self.cfg = cfg
        if cfg.log_dir is None:
            cfg.log_dir = os.path.join("captures", time.strftime("%Y%m%d-%H%M%S"))
        os.makedirs(os.path.join(cfg.log_dir, "bodies"), exist_ok=True)
        self.log = log or EventLog(os.path.join(cfg.log_dir, "server.jsonl"), verbose=cfg.verbose, echo=cfg.echo)
        self.protos = Protos(cfg.proto_dir)
        self.http = HttpServer(cfg, self.log, self.handle, self.now)
        self.controllers: dict[str, ControllerSession] = {}  # label -> session, in creation order
        self.gamepads: VirtualGamepads | None = None  # --gamepad: a virtual pad per controller
        self.mic_device: MicrophoneDevice | None = None  # --mic-device: the microphones as a device of this computer
        self._by_id: dict[str, ControllerSession] = {}  # device ids and serials
        self._by_ip: dict[str, ControllerSession] = {}  # latest controller seen from an address
        self._by_token: dict[str, ControllerSession] = {}  # display token -> session (GMsg attribution)
        self._free_slots: list[int] = []
        self._next_slot = 0
        self._create_lock = asyncio.Lock()  # one session is opened at a time (see controller_for)
        self.events: asyncio.Queue[dict[str, Any]] | None = None  # decoded input events of every controller
        self._body_seq = 0
        self._clock_base: float | None = None  # pinned epoch (cfg.clock_pin); None = real time
        self._clock_t0 = time.monotonic()
        self._stats_task: asyncio.Task[None] | None = None
        self._dns_proc: asyncio.subprocess.Process | None = None
        self._sntp_proc: asyncio.subprocess.Process | None = None
        self._helper_watchers: list[asyncio.Task[None]] = []
        self.event_streams: set[LiveStream] = set()  # the /_events clients
        #: Set by ``POST /_shutdown``; whoever runs the receiver waits for it, as for Ctrl-C.
        self.stop_requested = asyncio.Event()
        self.stopping = False
        self.started = False

    def now(self) -> float:
        """Wall time as the controllers should see it: real time, or (with ``--clock-pin``) the
        pinned epoch advanced by uptime.  Controllers take their clock from our Date header and
        GetCurrentTime replies."""
        if self._clock_base is None:
            return time.time()
        return self._clock_base + (time.monotonic() - self._clock_t0)

    # ---- lifecycle -----------------------------------------------------------------------
    async def start(self) -> None:
        self.events = asyncio.Queue(maxsize=EVENTS_KEPT)
        if self.cfg.mic_pcm and ffmpeg_path() is None:  # said before anything is made
            raise SetupError("--mic-pcm decodes the recordings with ffmpeg, and none was found on PATH")
        if self.cfg.mic_device is not None and ffmpeg_path() is None:
            raise SetupError("--mic-device decodes the microphone with ffmpeg, and none was found on PATH")
        ensure_certificate(self.cfg, self.log)
        if self.cfg.gamepad != "off" and self.gamepads is None:
            self.gamepads = VirtualGamepads.create(self.cfg, self.log, self)
        if self.gamepads is not None and self.cfg.start_game is None:
            # Rumble has no path but the game session, so a virtual pad implies StartGame.
            self.cfg.start_game = "auto"
            self.log(
                "gamepad_start_game", note="--gamepad switches StartGame on so the game's rumble reaches the controller"
            )
        if self.cfg.clock_pin:
            self._clock_base = resolve_clock_pin(self.cfg)
            self.log(
                "clock_pinned",
                source=self.cfg.clock_pin,
                at=datetime.datetime.fromtimestamp(self._clock_base, datetime.UTC).isoformat(),
                note="the controller judges the cert's validity against this clock",
            )
        if not self.cfg.advertise_ip:
            self.cfg.advertise_ip = local_ip_towards(self.cfg.controller_ip) or (
                self.cfg.bind if self.cfg.bind not in ("0.0.0.0", "") else "127.0.0.1"
            )
        await self.http.start()
        self._check_udp_ports()
        # Behind the ports: a receiver that was started twice by mistake ends on them, before it
        # touches the sound system the first one is using.
        if self.cfg.mic_device is not None and self.mic_device is None:
            self.mic_device = await asyncio.to_thread(self._open_mic_device)  # it asks the sound system
        if self.cfg.dns_upstream:
            await self._start_dns()
        if self.cfg.sntp:
            await self._start_sntp()
        self.started = True
        self._stats_task = asyncio.get_running_loop().create_task(self._stats_loop())
        self.log(
            "ready",
            version=__version__,
            https_port=self.http.https_port,
            http_ports=self.http.http_ports,
            udp_port=self.cfg.udp_port,
            game_udp_port=self.cfg.game_udp_port,
            udp_ports_per_controller=2,
            advertise_ip=self.cfg.advertise_ip,
            signaling_mode=self.cfg.signaling_mode,
            dtls_role=self.cfg.dtls_role,
            cert=self.cfg.cert,
            preset=self.cfg.preset,
            clearcut_block=self.cfg.clearcut_block,
            rpc_wire_id=f"{self.cfg.rpc_wire_id:#04x}",
            start_game=self.cfg.start_game,
            mic=self.cfg.mic,
            mic_device=None if self.mic_device is None else self.mic_device.output.name,
            mic_record=self.cfg.mic_record,
            log_dir=self.cfg.log_dir,
        )

    def _open_mic_device(self) -> MicrophoneDevice:
        """``--mic-device``: the device, found or made, and running. Not for the event loop."""
        device = MicrophoneDevice(
            open_output(self.cfg.mic_device or None, avoid=self._headset_capture(), log=self.log), self.log
        )
        device.start()
        return device

    def _headset_capture(self) -> str | None:
        """The device ``--audio-source`` captures the computer's sound from, as the capture names
        it, where the microphone is played into a device of that kind (Windows, macOS): played
        into that very one, it would go back into the headset."""
        spec = self.cfg.audio_source or ""
        if sys.platform.startswith("linux") or not (spec == "system" or spec.startswith("device:")):
            return None
        try:
            return source_from_spec(spec).label.removeprefix("capture ")
        except (SetupError, ValueError):  # no such device: the headset stream will say so itself
            return None

    def _check_udp_ports(self) -> None:
        """A controller's two UDP sockets are opened when it first shows up.  Taken ports would
        only be found then, as a controller that never connects: the first pair is tried now."""
        for port, protocol in ((self.cfg.udp_port, "UDP (display link)"), (self.cfg.game_udp_port, "UDP (game)")):
            if not port:
                continue
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
                try:
                    probe.bind((self.cfg.bind, port))
                except OSError as e:
                    raise OSError(bind_hint(port, protocol, e)) from e

    async def stop(self) -> None:
        self.stopping = True
        self.live_changed()  # the /_events streams end here, before their listeners are waited for
        if self._stats_task:
            self._stats_task.cancel()
            self._stats_task = None
        for ctl in list(self.controllers.values()):
            ctl.stop()
        await asyncio.gather(*(ctl.wait_microphone_closed() for ctl in self.controllers.values()))
        if self.mic_device is not None:
            await asyncio.to_thread(self.mic_device.stop)  # the device is removed, the voices end
        if self.gamepads is not None:
            self.gamepads.close()
            await self.gamepads.wait_closed()
        await self.http.stop()
        for watcher in self._helper_watchers:  # a helper stopped here is no news
            watcher.cancel()
        self._helper_watchers.clear()
        for proc in (self._dns_proc, self._sntp_proc):
            if proc and proc.returncode is None:
                proc.terminate()
                try:
                    await asyncio.wait_for(proc.wait(), 3)
                except TimeoutError:
                    proc.kill()
        self.log(
            "stopped",
            controllers={
                ctl.label: {
                    "rtc_stats": ctl.endpoint.stats,
                    "game_rtc_stats": ctl.game.endpoint.stats,
                    "input_stats": dict(ctl.input.stats),
                }
                for ctl in self.controllers.values()
            },
        )
        self.log.close()

    async def _spawn_helper(self, name: str, args: list[str], out_name: str) -> asyncio.subprocess.Process:
        """Run a helper process with its output in the run directory (see :mod:`stadiacast.helpers`)
        and watch it: a helper is meant to run for as long as the receiver, so one that exits is
        logged, with the last lines it wrote (the port it could not bind, usually)."""
        assert self.cfg.log_dir is not None
        out_path = os.path.join(self.cfg.log_dir, out_name)
        with open(out_path, "ab") as out:
            proc = await asyncio.create_subprocess_exec(*helper_command(name, args), stdout=out, stderr=out)
        watcher = asyncio.get_running_loop().create_task(self._watch_helper(name, proc, out_path))
        self._helper_watchers.append(watcher)
        return proc

    async def _watch_helper(self, name: str, proc: asyncio.subprocess.Process, out_path: str) -> None:
        code = await proc.wait()
        self.log("helper_exited", helper=name, pid=proc.pid, returncode=code, output=_tail(out_path))

    async def _start_dns(self) -> None:
        assert self.cfg.log_dir is not None and self.cfg.dns_upstream is not None and self.cfg.advertise_ip is not None
        patterns = ["*.googleapis.com", "googleapis.com", *self.cfg.dns_redirect]
        args = [
            "--upstream", self.cfg.dns_upstream, "--redirect-ip", self.cfg.advertise_ip,
            "--controller-ip", self.cfg.controller_ip, "--log", os.path.join(self.cfg.log_dir, "dns.jsonl"),
        ]  # fmt: skip
        args.extend(arg for pat in patterns for arg in ("--redirect", pat))
        nxdomain: list[str] = []
        if self.cfg.clearcut_block == "dns":
            # The first Clearcut upload (batcher tick at ~6 s uptime) is followed by radio silence
            # within ~0.3 s in every wake; a failed upload is requeued with the next tick 60 s out,
            # letting a queued v1:ResolveDiscovery reach the wire.
            nxdomain = list(CLEARCUT_HOSTS)
            args.extend(arg for host in nxdomain for arg in ("--nxdomain", host))
        self._dns_proc = await self._spawn_helper(DNS_SINK, args, "dns.out")
        self.log(
            "dns_sink_started",
            pid=self._dns_proc.pid,
            upstream=self.cfg.dns_upstream,
            redirect_ip=self.cfg.advertise_ip,
            redirect=patterns,
            nxdomain=nxdomain,
        )

    async def _start_sntp(self) -> None:
        """The firmware's lwIP SNTP client asks time.google.com; the signed RPC headers need a wall
        clock, so answer SNTP ourselves (the DNS sink points the name at us)."""
        assert self.cfg.log_dir is not None
        args = ["--controller-ip", self.cfg.controller_ip, "--log", os.path.join(self.cfg.log_dir, "sntp.jsonl")]
        self._sntp_proc = await self._spawn_helper(SNTP_SERVER, args, "sntp.out")
        self.log("sntp_server_started", pid=self._sntp_proc.pid, port=123)

    # ---- the controller registry ---------------------------------------------------------
    def find(self, name: str) -> ControllerSession | None:
        """A controller by label (``c0``), device id, serial, display token or address."""
        return self.controllers.get(name) or self._by_id.get(name) or self._by_token.get(name) or self._by_ip.get(name)

    def single(self) -> ControllerSession:
        """The one known controller (tests and single-controller tooling)."""
        if len(self.controllers) != 1:
            raise LookupError(f"{len(self.controllers)} controllers known: {sorted(self.controllers)}")
        return next(iter(self.controllers.values()))

    async def controller_for(
        self, req: HttpRequest, *, device_id: str | None = None, token: str | None = None, create: bool = True
    ) -> ControllerSession | None:
        """The session a request belongs to, created on first sight when ``create`` is set.

        Identification order: the GMsg token we issued, the ids the firmware sends (the body
        ``device_id`` and the ``controller-cloud-device-id`` / ``controller-device-id`` headers),
        then the peer address.  A request without any id from a new address creates a session
        keyed by that address, which later ids adopt.
        """
        ip = req.peer[0] if req.peer else None
        cloud = req.header("controller-cloud-device-id")
        serial = req.header("controller-device-id")
        ids = [x for x in (device_id, cloud, serial) if x]
        ctl = self._known(token, ids, ip)
        if ctl is None and create:
            key = ids[0] if ids else (f"ip:{ip}" if ip else None)
            if key is None:
                return None
            async with self._create_lock:
                # Opening a session waits for its sockets, and another request of the same controller
                # may have opened it in the meantime: look again before creating a second one.
                ctl = self._known(token, ids, ip) or await self._create(key, ip)
        if ctl is not None:
            ctl.touch(ip, device_id=device_id or cloud, serial=serial)
            for ident in ids:
                self._by_id[ident] = ctl
            if ip:
                self._by_ip[ip] = ctl
        return ctl

    def _known(self, token: str | None, ids: list[str], ip: str | None) -> ControllerSession | None:
        """The session already open for a request with this token, these ids and this address."""
        ctl = self._by_token.get(token) if token else None
        for ident in ids:
            if ctl is not None:
                break
            ctl = self._by_id.get(ident)
        if ctl is None and ip:
            known = self._by_ip.get(ip)
            if known is not None and (not ids or known.device_id is None):
                ctl = known  # the same address, not identified (yet): the controller we know there
        return ctl

    async def _create(self, key: str, ip: str | None) -> ControllerSession:
        """Open a session, with ``_create_lock`` held.  Past :data:`MAX_CONTROLLERS` the session idle
        the longest makes room, and the new one binds the UDP ports that one held."""
        if len(self.controllers) >= MAX_CONTROLLERS:
            evicted = min(self.controllers.values(), key=lambda c: c.last_seen)
            self._evict(evicted)
            await evicted.wait_closed()
        slot = self._free_slots.pop(0) if self._free_slots else self._next_slot
        if slot == self._next_slot:
            self._next_slot += 1
        ctl = ControllerSession(self, slot, key, ip)
        # every controller gets its own pair of UDP sockets: base port + 2 * slot (0 = ephemeral)
        udp = self.cfg.udp_port + 2 * slot if self.cfg.udp_port else 0
        game_udp = self.cfg.game_udp_port + 2 * slot if self.cfg.game_udp_port else 0
        try:
            await ctl.start(self.cfg.bind, udp, game_udp)
        except OSError:
            # A port that another program holds: the slot goes back, so that the controller's next
            # request tries the same ports again instead of walking up to the next pair.
            ctl.stop()
            await ctl.wait_closed()
            self._release_slot(slot)
            raise
        self.controllers[ctl.label] = ctl
        self._by_token[ctl.display_token] = ctl
        self.log(
            "controller_new",
            controller=ctl.label,
            key=key,
            ip=ip,
            udp_port=ctl.endpoint.local_port,
            game_udp_port=ctl.game.endpoint.local_port,
            display_token=ctl.display_token,
            controllers=len(self.controllers),
        )
        self.live_changed()
        return ctl

    def _evict(self, ctl: ControllerSession) -> None:
        self.log(
            "controller_evicted",
            controller=ctl.label,
            key=ctl.key,
            ip=ctl.ip,
            idle_s=round(time.monotonic() - ctl.last_seen),
        )
        ctl.stop()
        self.controllers.pop(ctl.label, None)
        self._by_token.pop(ctl.display_token, None)
        for table in (self._by_id, self._by_ip):
            for k in [k for k, v in table.items() if v is ctl]:
                del table[k]
        self._release_slot(ctl.slot)
        self.live_changed()

    def _release_slot(self, slot: int) -> None:
        self._free_slots.append(slot)
        self._free_slots.sort()

    def _pick(self, req: HttpRequest, body: dict[str, Any] | None = None) -> ControllerSession | HttpResponse:
        """The controller a local control request (``/_rumble``, ``/_start_game``) is for.

        ``?controller=<label|device id|ip>`` (or the same key in a JSON body) selects one; with a
        single known controller it may be omitted.
        """
        name = parse_qs(req.query).get("controller", [None])[0] or (body or {}).get("controller")
        if name:
            ctl = self.find(str(name))
            if ctl is None:
                return self._json(404, {"error": f"no controller {name!r}", "controllers": self._controller_index()})
            return ctl
        if len(self.controllers) == 1:
            return next(iter(self.controllers.values()))
        if not self.controllers:
            return self._json(409, {"error": "no controller has connected yet"})
        return self._json(
            400, {"error": "several controllers: pass ?controller=<label>", "controllers": self._controller_index()}
        )

    def _controller_index(self) -> dict[str, dict[str, Any]]:
        return {
            c.label: {"device_id": c.device_id, "ip": c.ip, "display": c.display_state, "game": c.game.state["state"]}
            for c in self.controllers.values()
        }

    @staticmethod
    def _json(status: int, body: dict[str, Any], handler: str = "control") -> HttpResponse:
        return HttpResponse(status, json.dumps(body, default=str).encode(), "application/json", handler=handler)

    # ---- HTTP routing --------------------------------------------------------------------
    async def handle(self, req: HttpRequest) -> HttpResponse:
        """Route one request and write the ``http_request`` record (bodies are dumped to disk)."""
        t0 = time.monotonic()
        body_file = self._dump_body(req)
        try:
            resp = await self._route(req)
        except Exception as e:  # keep serving: the record below says what failed
            self.log("handler_error", conn=req.conn_id, path=req.path, error=repr(e), tb=traceback.format_exc()[-1200:])
            resp = HttpResponse(500, b"", handler="error")
        rec: dict[str, Any] = {
            "conn": req.conn_id,
            "peer": req.peer,
            "sni": req.sni,
            "method": req.method,
            "host": req.host,
            "path": req.path,
            "query": req.query,
            "version": req.version,
            "request_headers": req.headers,
            "body_len": len(req.body),
            "status": resp.status,
            "response_len": len(resp.body),
            "handler": resp.handler,
            "ms": round((time.monotonic() - t0) * 1000, 1),
            "body_file": body_file,
        }
        known = self._by_ip.get(req.peer[0]) if req.peer else None
        if known is not None:
            rec["controller"] = known.label
        if req.body:
            rec["body_hex"] = req.body[:2048].hex()
            head = req.body[:LOGGED_BODY_BYTES]
            text = printable(head)
            if text is not None:
                rec["body_text"] = text[:4096]
            else:
                rec["decoded"] = decode_unknown(head)
        if resp.body:
            rec["response_hex"] = resp.body[:1024].hex()
        if resp.note:
            rec["note"] = resp.note
        if resp.close:
            rec["connection_close"] = True
        rec.update(resp.extra_log)
        self.log("http_request", **rec)
        return resp

    def _dump_body(self, req: HttpRequest) -> str | None:
        if not req.body:
            return None
        assert self.cfg.log_dir is not None
        self._body_seq += 1
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{req.host}{req.path}")[:80]
        path = os.path.join(self.cfg.log_dir, "bodies", f"{self._body_seq:04d}-{safe}.bin")
        try:
            with open(path, "wb") as fh:
                fh.write(req.body)
        except OSError as e:  # a full disk: the request is still answered
            self.log("body_not_saved", path=path, error=str(e))
            return None
        return path

    async def _route(self, req: HttpRequest) -> HttpResponse:
        host, path = req.host.lower(), req.path
        if path.startswith("/_") and req.method != "GET" and req.header("origin") is not None:
            # A browser names the page a request comes from.  The control endpoints have no login,
            # so a page on any site could otherwise move the motors or start a stream.
            return self._json(403, {"error": "the control endpoints take no requests from web pages"})
        if path == "/generate_204" or host.startswith("connectivitycheck."):
            return HttpResponse(204, handler="netcheck")
        if path.startswith("/cast/chromecast/device/stadiaconfig"):
            return await self._stadiaconfig(req)
        if path == "/service/update2":
            return self._omaha(req)
        if path == "/log/batch":
            return self._clearcut(req)
        if path == "/gmsg" or host.startswith("cloudcast-gmsg"):
            return await self._gmsg(req)
        m = RPC_PATH.match(path)
        if m:
            return await self._cloudcast_rpc(req, m.group(1))
        # Anything else: a bare WebRtcSdp / bundle in the body is still answered
        # (legacy fake-controller direction, unexpected envelopes).
        if req.body:
            found = self.protos.sniff_signaling(req.body)
            if found:
                ctl = await self.controller_for(req)
                if ctl is not None:
                    return ctl.handle_signaling(*found)
        if path.startswith("/cr/report"):
            return HttpResponse(200, b"", "text/plain", handler="crash_report")
        if path == "/setup/send_log_report":
            return HttpResponse(200, b'{"status":"ok"}', "application/json", handler="send_log_report")
        if path == "/_status":
            return HttpResponse(
                200, json.dumps(self.status(), indent=1, default=str).encode(), "application/json", handler="status"
            )
        if path == "/_input":
            return self._json(200, self.live_state(), handler="input")
        if path == "/_events":
            return self._events(req)
        if path == "/_shutdown":
            return self._shutdown(req)
        if path in ("/_start_game", "/_rumble"):
            return self._control(req)
        if path == "/_audio":
            return await self._audio(req)
        if path == "/_mic":
            return self._mic(req)
        if path in self.cfg.offer_on:
            ctl = await self.controller_for(req)
            if ctl is not None:
                return ctl.serve_offer("offer_on")
        return HttpResponse(404, b"", handler="unhandled", note="no handler for this path; body dumped")

    def _control(self, req: HttpRequest) -> HttpResponse:
        """The local control endpoints, dispatched to the selected controller."""
        body: dict[str, Any] | None = None
        if req.body.strip():
            try:
                parsed = json.loads(req.body)
                body = parsed if isinstance(parsed, dict) else None
            except ValueError:
                body = None  # the game session reports the malformed body itself
        picked = self._pick(req, body)
        if isinstance(picked, HttpResponse):
            return picked
        if req.path == "/_start_game":
            return picked.game.handle_start_game_request(req)
        return picked.game.handle_rumble_request(req)

    async def _audio(self, req: HttpRequest) -> HttpResponse:
        """``/_audio``: the headset stream.

        ``GET`` shows it and ignores any body, so a read never changes the stream.  ``POST`` takes
        ``{"do": ...}``: ``start`` (``source`` as for ``--audio-source``, optional ``volume`` and
        ``application`` as for ``--audio-application``), ``stop``, ``volume`` (``volume``) or
        ``mode`` (``mode``, the SetAudioModeRequest value).
        """
        if req.method == "GET":
            picked = self._pick(req)
            if isinstance(picked, HttpResponse):
                return picked
            return self._json(200, {**picked.audio_state(), "controller": picked.label}, handler="audio")
        if req.method != "POST":
            return HttpResponse(405, b"", handler="audio")
        body: dict[str, Any] = {}
        if req.body.strip():
            try:
                parsed = json.loads(req.body)
                body = parsed if isinstance(parsed, dict) else {}
            except ValueError:
                return self._json(400, {"error": "the body is not JSON"}, handler="audio")
        picked = self._pick(req, body)
        if isinstance(picked, HttpResponse):
            return picked
        action = body.get("do")
        try:
            if action == "start":
                out = await picked.audio_start_spec(
                    str(body.get("source") or "tone"), volume=body.get("volume"), application=body.get("application")
                )
            elif action == "stop":
                out = await picked.audio_stop()
            elif action == "volume":
                out = await picked.audio_set_volume(float(body["volume"]))
            elif action == "mode":
                out = picked.set_audio_mode(int(body["mode"]), f3=True)
            else:
                return self._json(
                    400,
                    {"error": f"unknown do={action!r}", "actions": ["start", "stop", "volume", "mode"]},
                    handler="audio",
                )
        except (KeyError, TypeError, ValueError, SetupError) as e:
            # a missing or malformed field, a bad source spelling, or (SetupError) something this
            # computer lacks, ffmpeg or a capture device: the caller's to fix, so a 400 that says which
            return self._json(400, {"error": str(e)}, handler="audio")
        out["controller"] = picked.label
        return self._json(200, out, handler="audio")

    def _mic(self, req: HttpRequest) -> HttpResponse:
        """``/_mic``: a controller's microphone.

        ``GET`` shows the switch, the recordings and the computer's device, and ignores any
        body, so a read never opens the microphone.  ``POST`` takes ``{"do": ...}``: ``on`` or
        ``off`` (the switch), ``record`` (``on``: whether what arrives is written into files),
        ``pcm`` (``on``: whether recordings are decoded to PCM as well) or ``ptt`` (``on``: whether
        the Assistant button is the switch).  A ``POST`` is taken over the loopback address only:
        who may open a microphone is whoever sits at the receiver's computer, or started it with
        ``--mic``.  ``on`` is a 409 for a controller whose link is not READY, and while nothing
        would take the sound, neither a device nor a recording.
        """
        if req.method == "GET":
            picked = self._pick(req)
            if isinstance(picked, HttpResponse):
                return picked
            device = None if self.mic_device is None else self.mic_device.state()
            return self._json(200, {**picked.mic_state(), "controller": picked.label, "device": device}, handler="mic")
        if req.method != "POST":
            return HttpResponse(405, b"", handler="mic")
        if req.peer is None or not is_loopback(req.peer[0]):
            return self._json(403, {"error": "only over the loopback address (127.0.0.1)"}, handler="mic")
        body: dict[str, Any] = {}
        if req.body.strip():
            try:
                parsed = json.loads(req.body)
                body = parsed if isinstance(parsed, dict) else {}
            except (ValueError, RecursionError):  # the second: brackets nested a thousand deep
                return self._json(400, {"error": "the body is not JSON"}, handler="mic")
        picked = self._pick(req, body)
        if isinstance(picked, HttpResponse):
            return picked
        action, on = body.get("do"), body.get("on", True)
        if action in ("on", "off") and "on" in body:  # {"do": "on", "on": false} would switch it on
            return self._json(
                400, {"error": "do says on or off by itself; on goes with pcm, ptt and record"}, handler="mic"
            )
        if action in ("pcm", "ptt", "record") and not isinstance(on, bool):
            return self._json(400, {"error": "on is true or false"}, handler="mic")
        if action == "on":
            out: dict[str, Any] = picked.mic_start(reason="api")
            if out.pop("nowhere", False):
                out["error"] = (
                    "nothing takes the microphone: start the receiver with --mic-device or --mic-record, or switch"
                    ' the recording on first ({"do": "record", "on": true})'
                )
            elif not out["ok"]:
                out["error"] = "the display link is not READY: nothing was sent"
        elif action == "off":
            out = picked.mic_stop(reason="api")
            out["ok"] = True  # off is what it is now, whether the controller could be told or not
        elif action == "pcm":
            try:
                out = picked.set_mic_pcm(on)
            except SetupError as e:
                return self._json(400, {"error": str(e)}, handler="mic")
        elif action == "ptt":
            out = picked.set_mic_ptt(on)
        elif action == "record":
            out = picked.set_mic_record(on)
        else:
            return self._json(
                400,
                {"error": f"unknown do={action!r}", "actions": ["on", "off", "pcm", "ptt", "record"]},
                handler="mic",
            )
        out["controller"] = picked.label
        return self._json(409 if "error" in out else 200, out, handler="mic")

    def _events(self, req: HttpRequest) -> HttpResponse:
        """``GET /_events``: the live state as server-sent events (:class:`LiveStream`)."""
        if req.method != "GET":
            return HttpResponse(405, b"", handler="events")
        if len(self.event_streams) >= MAX_EVENT_STREAMS:
            return self._json(503, {"error": f"{MAX_EVENT_STREAMS} streams are open already"}, handler="events")
        stream = LiveStream(self)
        self.event_streams.add(stream)
        return HttpResponse(
            200,
            content_type="text/event-stream",
            headers=[("Cache-Control", "no-store")],
            handler="events",
            stream=stream,
        )

    def _shutdown(self, req: HttpRequest) -> HttpResponse:
        """``POST /_shutdown``: stop the receiver as Ctrl-C does, helper processes, streams and
        virtual pads included.  A receiver that runs in the background on Windows cannot be sent a
        Ctrl-C, and one that is killed leaves its helpers behind.  Taken over the loopback address
        only: a request to another of this computer's addresses is refused like one from elsewhere."""
        if req.method != "POST":
            return HttpResponse(405, b"", handler="shutdown")
        if req.peer is None or not is_loopback(req.peer[0]):
            return self._json(403, {"error": "only over the loopback address (127.0.0.1)"}, handler="shutdown")
        self.log("shutdown_requested", peer=req.peer)
        self.stop_requested.set()
        return HttpResponse(200, b'{"ok": true}', "application/json", handler="shutdown", close=True)

    # ---- boot-time endpoints -------------------------------------------------------------
    async def _stadiaconfig(self, req: HttpRequest) -> HttpResponse:
        mode = self.cfg.stadiaconfig
        if mode.startswith("file:"):
            with open(mode[5:], "rb") as fh:
                return HttpResponse(200, fh.read(), "application/json", handler="stadiaconfig(file)")
        if mode.startswith("json:"):
            return HttpResponse(200, mode[5:].encode(), "application/json", handler="stadiaconfig(json)")
        upstream = f"https://clients3.google.com{req.path}" + (f"?{req.query}" if req.query else "")
        status, ctype, body, err = await fetch_upstream(upstream, self.cfg.advertise_ip)
        if status:
            return HttpResponse(
                status,
                body,
                ctype or "application/json",
                handler="stadiaconfig(passthrough)",
                extra_log={"upstream": upstream},
            )
        return HttpResponse(
            200,
            b"{}",
            "application/json",
            handler="stadiaconfig(fallback)",
            note=f"upstream fetch failed: {err}",
            extra_log={"upstream": upstream},
        )

    def _omaha(self, req: HttpRequest) -> HttpResponse:
        """Omaha update check: always "no update"."""
        # the search can take time quadratic in its input, on the event loop: a bounded input
        text = req.body[:OMAHA_REQUEST_BYTES].decode("utf-8", "replace")
        apps = re.findall(r'<app\s[^>]*appid="([^"]+)"', text)[:OMAHA_APPS]
        now = datetime.datetime.now(datetime.UTC)
        midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        elapsed_days = (now.date() - datetime.date(2007, 1, 1)).days
        body = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            f'<response protocol="3.0" server="{SERVER_NAME}">',
            f'<daystart elapsed_seconds="{int((now - midnight).total_seconds())}" elapsed_days="{elapsed_days}"/>',
        ]
        body.extend(
            f'<app appid="{html.escape(appid)}" status="ok"><updatecheck status="noupdate"/><ping status="ok"/></app>'
            for appid in apps or ["{00000000-0000-0000-0000-000000000000}"]
        )
        body.append("</response>")
        return HttpResponse(
            200,
            "".join(body).encode(),
            "text/xml; charset=utf-8",
            handler="omaha",
            extra_log={"omaha_request": text[:2000], "appids": apps},
        )

    def _clearcut(self, req: HttpRequest) -> HttpResponse:
        """Clearcut analytics upload: decode for the log, answer a LogResponse."""
        info: dict[str, Any] = {}
        try:
            batch = self.protos.BatchedLogRequest()
            batch.ParseFromString(req.body)
            info["log_requests"] = len(batch.log_request)
            info["events"] = sum(len(r.log_event) for r in batch.log_request)
            srcs = {
                self.protos.enum_name("chrome.cloudcast.proto.common.LogRequest.LogSource", r.log_source)
                for r in batch.log_request
                if r.HasField("log_source")
            }
            info["log_sources"] = sorted(srcs)
            for r in batch.log_request:
                if r.HasField("client_info"):
                    info["client_info"] = self.protos.to_dict(r.client_info)
                    break
        except DecodeError as e:
            info["decode_error"] = str(e)
        resp = self.protos.LogResponse()
        resp.next_request_wait_millis = 30 * 60 * 1000
        # The firmware's HTTPS requests are serialized and its Clearcut uploader never closes its
        # connection.  When the boot upload went out before v1:ResolveDiscovery, a kept-alive
        # connection here was followed by no ResolveDiscovery at all.
        return HttpResponse(
            200,
            resp.SerializeToString(),
            "application/octet-stream",
            handler="clearcut",
            extra_log={"clearcut": info},
            close=self.cfg.clearcut_close,
        )

    # ---- cloudcast discovery RPCs (schemas/discovery_api.proto) --------------------------
    async def _cloudcast_rpc(self, req: HttpRequest, method: str) -> HttpResponse:
        extra: dict[str, Any] = {
            "rpc": method,
            "api_key": parse_qs(req.query).get("key", [None])[0],
            "controller_device_id": req.header("controller-device-id"),
            "controller_cloud_device_id": req.header("controller-cloud-device-id"),
        }
        if req.method != "POST":
            return HttpResponse(405, handler=f"rpc:{method}", extra_log=extra)
        p = self.protos
        request = None
        if p.rpc_request_class(method) is not None:
            try:
                request = p.parse_rpc_request(method, req.body)
                extra["request"] = p.to_dict(request)
            except DecodeError as e:
                extra["request_decode_error"] = str(e)
                found = p.sniff_signaling(req.body) if req.body else None
                if found:  # not a firmware request body: a bare SDP (legacy fake controller)
                    ctl = await self.controller_for(req)
                    if ctl is not None:
                        return ctl.handle_signaling(*found)
        device_id = getattr(request, "device_id", "") or None
        ctl = await self.controller_for(req, device_id=device_id)
        if ctl is None:
            return HttpResponse(
                400, b"", handler=f"rpc:{method}", note="request without any controller identity", extra_log=extra
            )
        extra["controller"] = ctl.label
        canned = self.cfg.rpc_responses.get(method)
        if canned is not None:
            return HttpResponse(200, canned, "application/x-protobuf", handler=f"rpc:{method}(canned)", extra_log=extra)
        if f"/v1:{method}" in self.cfg.offer_on:
            return ctl.serve_offer(f"rpc:{method}")
        note = None
        resp = None
        if method == "FirmwareVersionCheck":
            resp = p.FirmwareVersionCheckResponse()
            resp.requires_update = False
        elif method == "RegisterController":
            resp, note = ctl.register(request, extra)
        elif method == "DiscoverDisplay":
            resp, note = ctl.discover(request, extra)
        elif method == "ResolveDiscovery":
            note = (
                "ResolveDiscovery: sent on entering S/UNREGISTERING, right after OnConnected registered the "
                "RPC reader; the firmware ignores the body (event 13 UNREGISTERED); empty 200"
            )
            ctl.on_discovery_resolved()
        else:
            note = "unknown RPC; empty message"
        body = b""
        if resp is not None:
            overrides = self.cfg.rpc_fields.get(method)
            if overrides:
                json_format.ParseDict(overrides, resp)
                extra["response_overrides"] = overrides
            body = resp.SerializeToString()
            extra["response"] = p.to_dict(resp)
        if note:
            extra["assumption"] = note
        return HttpResponse(200, body, "application/x-protobuf", handler=f"rpc:{method}", note=note, extra_log=extra)

    # ---- GMsg push channel ---------------------------------------------------------------
    async def _gmsg(self, req: HttpRequest) -> HttpResponse:
        """A ``/gmsg`` poll: find the controller behind it and let its session answer."""
        p = self.protos
        extra: dict[str, Any] = {}
        poll = None
        if req.body:
            try:
                poll = p.GmsgPollRequest()
                poll.ParseFromString(req.body)
                extra["poll"] = p.to_dict(poll)
            except DecodeError as e:
                poll = None
                extra["poll_decode_error"] = str(e)
        canned = self.cfg.rpc_responses.get("gmsg")
        if canned is not None:
            return HttpResponse(200, canned, "application/x-protobuf", handler="gmsg(canned)", extra_log=extra)
        token = poll.subscription if poll is not None and poll.subscription else None
        ctl = await self.controller_for(req, token=token, create=False)
        if ctl is None:
            self.log("gmsg_unattributed", peer=req.peer, token=token)
            return HttpResponse(
                200,
                b"",
                "application/x-protobuf",
                handler="gmsg:unattributed",
                extra_log=extra,
                note="poll from a controller that never registered: empty body (no message)",
            )
        extra["controller"] = ctl.label
        return await ctl.gmsg_poll(poll, extra)

    # ---- events and status ---------------------------------------------------------------
    def publish_event(self, ev: dict[str, Any]) -> None:
        """A decoded input event from one of the controllers (``ev["controller"]`` says which)."""
        if self.events is not None:
            if self.events.full():  # nobody is reading: make room for the newest
                self.events.get_nowait()
            self.events.put_nowait(ev)
        if self.gamepads is not None:
            self.gamepads.on_event(ev)

    async def wait_event(self, timeout: float = 5.0) -> dict[str, Any]:
        assert self.events is not None
        return await asyncio.wait_for(self.events.get(), timeout)

    async def _stats_loop(self, interval: float = 10.0) -> None:
        """Write each controller's counters to the log whenever something has come in from it, so
        they survive an unclean stop.  What the receiver sends alone does not count: its checks to a
        controller that is off would write a record every ten seconds."""

        def inbound(stats: dict[str, int]) -> dict[str, int]:
            return {k: v for k, v in stats.items() if not k.endswith("_out")}

        last: dict[str, Any] = {}
        try:
            while True:
                await asyncio.sleep(interval)
                for ctl in list(self.controllers.values()):
                    snap = (
                        dict(ctl.endpoint.stats),
                        ctl.session["display"]["rpc_in"],
                        dict(ctl.session["display"]["wire_in"]),
                        dict(ctl.game.endpoint.stats),
                        dict(ctl.game.state["wire_in"]),
                    )
                    came_in = (inbound(snap[0]), snap[1], snap[2], inbound(snap[3]), snap[4])
                    if came_in != last.get(ctl.label):
                        last[ctl.label] = came_in
                        ctl.log(
                            "rtc_stats",
                            _quiet=True,
                            rtc_stats=snap[0],
                            rpc_in=snap[1],
                            wire_in=snap[2],
                            display_state=ctl.display_state,
                            game_rtc_stats=snap[3],
                            game_wire_in=snap[4],
                            game_state=ctl.game.state["state"],
                        )
        except asyncio.CancelledError:
            pass

    def live_changed(self) -> None:
        """Something the live state shows has changed: every ``/_events`` stream sends it."""
        for stream in self.event_streams:
            stream.changed.set()

    def live_state(self) -> dict[str, Any]:
        """The ``/_input`` document: what each controller is doing right now.

        The short version of ``/_status``, which is everything the receiver knows; ``/_events``
        sends it whenever it changes.  Per controller: ``display_state`` (``ready`` or ``input``
        once the link is up), ``ip``, ``last_seen_s`` (seconds since anything came from it; a
        connected controller is heard from every 1.5 s), ``battery_percent``, ``headset``,
        ``microphone`` (whether it was asked for its microphone), its virtual ``gamepad`` as in
        ``/_status``, and ``input``: the latest report with the held buttons by name and
        ``age_s``, or ``None`` when this boot has sent none.
        """
        now = time.monotonic()
        pads = self.gamepads.status() if self.gamepads is not None else {}
        controllers: dict[str, Any] = {}
        for ctl in self.controllers.values():
            display = ctl.session["display"]
            report: dict[str, Any] | None = None
            if ctl.latest_input is not None:
                state, at = ctl.latest_input
                report = {
                    "buttons": state.buttons,
                    "held": state.held(),
                    "lx": state.lx,
                    "ly": state.ly,
                    "rx": state.rx,
                    "ry": state.ry,
                    "l2": state.l2,
                    "r2": state.r2,
                    "age_s": round(now - at, 2),
                }
            controllers[ctl.label] = {
                "display_state": ctl.display_state,
                "ip": ctl.ip,
                "last_seen_s": round(now - ctl.last_seen, 1),
                "battery_percent": display["battery_percent"],
                "headset": display["headset"],
                "microphone": ctl.mic_on,
                "gamepad": pads.get(ctl.label),
                "input": report,
            }
        return {"version": __version__, "gamepad": self.cfg.gamepad, "controllers": controllers}

    def status(self) -> dict[str, Any]:
        """The ``/_status`` document."""
        return {
            "version": __version__,
            "controllers": {ctl.label: ctl.status() for ctl in self.controllers.values()},
            "advertise_ip": self.cfg.advertise_ip,
            "gamepads": self.gamepads.status() if self.gamepads is not None else None,
            "mic_device": self.mic_device.state() if self.mic_device is not None else None,
            "event_counts": self.log.counts,
            "log_dir": self.cfg.log_dir,
        }
