const sections = {
    pending: document.getElementById('Pending'),
    active: document.getElementById('Active'),
};

const buttons = {
    0: false,
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
    6: 0,
    7: 0,
    8: false,
    9: false,
    10: false,
    11: false,
    12: false,
    13: false,
    14: false,
    15: false,
    16: false,
    17: false,
    18: false,
    "lx": 0,
    "ly": 0,
    "rx": 0,
    "ry": 0,
}

const buttonElems = {
    0: document.getElementById('ButtonA'),
    1: document.getElementById('ButtonB'),
    2: document.getElementById('ButtonX'),
    3: document.getElementById('ButtonY'),
    4: document.getElementById('ShoulderLeft'),
    5: document.getElementById('ShoulderRight'),
    6: document.getElementById('TriggerLeft'),
    7: document.getElementById('TriggerRight'),
    8: document.getElementById('ButtonOptions'),
    9: document.getElementById('ButtonMenu'),
    10: document.getElementById('ButtonLeftStick'),
    11: document.getElementById('ButtonRightStick'),
    12: document.getElementById('DpadUp'),
    13: document.getElementById('DpadDown'),
    14: document.getElementById('DpadLeft'),
    15: document.getElementById('DpadRight'),
    16: document.getElementById('ButtonStadia'),
    17: document.getElementById('ButtonAssist'),
    18: document.getElementById('ButtonCapture'),
    LStick: document.getElementById('StickLeft'),
    RStick: document.getElementById('StickRight'),
}


let url = window.location.href.replace("http", "ws");

let gamepadIndex;
let socket
let connectSocket = () => {
    socket = new WebSocket(url + '/controller');
    socket.onopen = function (e) {
        console.log("[open] Connection established");
    };
    socket.onmessage = function (event) {
        console.log(`[message] Data received from server: ${event.data}`);
        let data = JSON.parse(event.data);
        console.log(data.lm);
        console.log(data.sm);
        // vibrate controller
        if (gamepadIndex !== undefined) {
            vibrate(data).then(() => {
                if (data.lm > 0 || data.sm > 0) {
                    vibrate(data);
                }
            });
        }
    };

    socket.onclose = function (event) {
        connected = false;
        if (event.wasClean) {
            console.log(`[close] Connection closed cleanly, code=${event.code} reason=${event.reason}`);
        } else {
            console.log('[close] Connection died');
        }
    };

    socket.onerror = function (error) {
        console.log(`[error] ${error.message}`);
    };
}

connectSocket();
window.addEventListener('gamepadconnected', (event) => {
    sections.pending.classList.remove('visible');
    sections.active.classList.add('visible');
    gamepadIndex = 0;
});

window.addEventListener('gamepaddisconnected', () => {
    sections.active.classList.remove('visible');
    sections.pending.classList.add('visible');
    gamepadIndex = undefined;
});



let vibrate = async (data) => {
    if (navigator.getGamepads()[gamepadIndex].vibrationActuator)
        await navigator.getGamepads()[gamepadIndex].vibrationActuator.playEffect('dual-rumble', {
            startDelay: 0,
            duration: 500,
            weakMagnitude: data.sm / 255,
            strongMagnitude: data.lm / 255
        });
}

const updateController = () => {
    for (let buttonIndex = 0; buttonIndex < 19; buttonIndex++) {
        const buttonValue = buttons[buttonIndex];
        if (buttonElems[buttonIndex]) {
            if (buttonIndex == 6 || buttonIndex == 7) {
                buttonElems[buttonIndex].style.strokeDashoffset = 338 - buttonValue * 338;
                continue;
            }
            if (buttonValue) {
                buttonElems[buttonIndex].classList.add('active');
                continue;
            }
            buttonElems[buttonIndex].classList.remove('active');
        } else {
            console.log(buttonIndex);
        }
    }
    buttonElems.LStick.style.transform = `translate(${buttons['lx'] * 2}%, ${buttons['ly'] * 2}%)`;
    buttonElems.RStick.style.transform = `translate(${buttons['rx'] * 2}%, ${buttons['ry'] * 2}%)`;
}


const update = () => {
    if (gamepadIndex !== undefined) {
        const myGamepad = navigator.getGamepads()[gamepadIndex];
        if (myGamepad) {
            buttons["lx"] = myGamepad.axes[0];
            buttons["ly"] = myGamepad.axes[1];
            buttons["rx"] = myGamepad.axes[2];
            buttons["ry"] = myGamepad.axes[3];

            myGamepad.buttons.map(e => e.pressed).forEach((isPressed, buttonIndex) => {
                if (buttonIndex == 6 || buttonIndex == 7) {
                    buttons[buttonIndex] = myGamepad.buttons[buttonIndex].value;
                }
                else if (isPressed) {
                    buttons[buttonIndex] = true;
                } else {
                    buttons[buttonIndex] = false;
                }
            })
            updateController();
            if (socket.readyState == 1)
                socket.send(JSON.stringify(buttons));
        }
    }
}

const loop = () => {
    update();
    requestAnimationFrame(loop);
}
loop();
