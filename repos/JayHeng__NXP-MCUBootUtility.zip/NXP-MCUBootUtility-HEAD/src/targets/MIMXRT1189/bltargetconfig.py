#!/usr/bin/env python

# Copyright (c) 2014 Freescale Semiconductor, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# o Redistributions of source code must retain the above copyright notice, this list
#   of conditions and the following disclaimer.
#
# o Redistributions in binary form must reproduce the above copyright notice, this
#   list of conditions and the following disclaimer in the documentation and/or
#   other materials provided with the distribution.
#
# o Neither the name of Freescale Semiconductor, Inc. nor the names of its
#   contributors may be used to endorse or promote products derived from this
#   software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import sys, os
sys.path.append(os.path.abspath(".."))
from boot.memoryrange import MemoryRange
from ui import RTyyyy_uidef
from ui import RTyyyy_uidef_efuse
from ui import uidef
from run import RTyyyy_rundef
from run import rundef
from gen import gendef

cpu = 'MIMXRT1189'
board = 'EVK'
compiler = 'iar'
build = 'Release'

availablePeripherals = 0x11
romTargetVersion = None
romUsbVid = '0x1FC9'
romUsbPid = '0x014C'
hasSdpReadRegisterCmd = None
bootHeaderType = gendef.kBootHeaderType_Container
flashloaderUsbVid = '0x15A2'
flashloaderUsbPid = '0x0073'
flashloaderLoadAddr = None
flashloaderJumpAddr = None
availableCommands = 0x5EFDF
supportedPeripheralSpeed_uart = [4800, 9600, 19200, 57600, 115200] # @todo Verify
availableSecureBootTypes = [RTyyyy_uidef.kSecureBootType_Development
                            ]
hasRemappedFuse = False
availableBootDevices = [RTyyyy_uidef.kBootDevice_FlexspiNor,
                        RTyyyy_uidef.kBootDevice_UsdhcSd,
                        RTyyyy_uidef.kBootDevice_UsdhcMmc]
flexspiNorDevice = uidef.kFlexspiNorDevice_ISSI_IS25LP064A
flexspiNorMemBase0   = 0x38000000 # CM33 Secure
flexspiNorMemBase0Ns = 0x28000000 # CM33 Non-Secure
flexspiNorMemBase0Aliased   = 0x12000000
flexspiNorMemBase0AliasedNs = 0x02000000
flexspiNorMem0MaxSize = rundef.kBootDeviceMemXipSize_FlexspiNor128MB
flexspiNorMem0AliasedMaxSize = rundef.kBootDeviceMemXipSize_FlexspiNor32MB
flexspiNorMemBase1   = 0x14000000 # CM33 Secure
flexspiNorMemBase1Ns = 0x04000000 # CM33 Non-Secure
flexspiNorMemBase1Aliased   = 0x32000000
flexspiNorMemBase1AliasedNs = 0x22000000
flexspiNorMem1MaxSize = rundef.kBootDeviceMemXipSize_FlexspiNor64MB
flexspiNorMem1AliasedMaxSize = rundef.kBootDeviceMemXipSize_FlexspiNor32MB
flexspiFreqs = ['30MHz', '50MHz', '60MHz', '80MHz', '100MHz', '120MHz', '133MHz', '166MHz', '200MHz']
xspiNorEraseAlignment = 0x1 # in byte
xspiNorCfgInfoOffset = 0x400
xspiNorCfgInfoLen    = 0x200
xspiNorImgHdrOffset = 0x1000
flexspiNorEfuseBootCfg0Bits = 12
isNonXipImageAppliableForXipableDeviceUnderClosedHab = True
isSipFlexspiNorDevice = False
hasFlexspiNorDualImageBoot = True
hasFlexspiNorEcc = True
isEccTypeSetInFuseMiscConf = True
isSwEccSetAsDefaultInNandOpt = False
hasMultiUsdhcBootInstance = True
hwAuthHashEngine = "CAAM"

quadspiNorDevice = None
quadspiNorMemBase = None

ramFreeSpaceStart_LoadCommOpt        = 0x304C8000
ramFreeSpaceStart_LoadDekData        = 0x304C8100
ramFreeSpaceStart_LoadKeyBlobContext = 0x304C8200
ramFreeSpaceStart_LoadKeyBlobData    = 0x304C8300
ramFreeSpaceStart_LoadCfgBlock       = 0x304C9000
ramFreeSpaceStart_LoadPrdbOpt        = 0x304CA000
ramFreeSpaceStart_Rom                = 0x304CE000

registerAddrDict = RTyyyy_rundef.registerAddrDict_RT11yy
registerDefnDict  = RTyyyy_rundef.registerDefnDict_RT11yy

efusemapIndexDict = RTyyyy_uidef_efuse.efusemapIndexDict_RT118y
efusemapDefnDict  = RTyyyy_uidef_efuse.efusemapDefnDict_RT118y

isResetNeededForEfuseRefresh = True

efuseDescDiffDict = {
                     '0xc70_flexramcfg_bit21_16':RTyyyy_uidef_efuse.efuse_0xc70_flexramPartion512KB,
                    }

otpmapIndexDict = None
otpmapDefnDict  = None
otpDescDiffDict = None

ftfxNorMemBase = None
c040hdNorMemBase = None

sbLoaderVersion = gendef.kSbLoaderVersion_v1_0

# memory map
memoryRange = {
    # Code TCM_CM33, 256KByte
    'itcm' : MemoryRange(0x1FFC0000, 0x40000, 'state_itcm_mem.dat'),
    # Code TCM_CM33, 256KByte
    'itcm_ns' : MemoryRange(0x0FFC0000, 0x40000, 'state_itcm_ns_mem.dat'),
    # Code TCM_CM7, 512KByte
    'itcm_sec' : MemoryRange(0x30380000, 0x80000, 'state_itcm_sec_mem.dat'),
    # Code TCM_CM7, 512KByte
    'itcm_sec_ns' : MemoryRange(0x20380000, 0x80000, 'state_itcm_sec_ns_mem.dat'),
    # System TCM_CM33, 256KByte
    'dtcm' : MemoryRange(0x30000000, 0x40000, 'state_dtcm_mem.dat'),
    # System TCM_CM33, 256KByte
    'dtcm_ns' : MemoryRange(0x20000000, 0x40000, 'state_dtcm_ns_mem.dat'),
    # System TCM_CM7, 512KByte
    'dtcm_sec' : MemoryRange(0x30400000, 0x80000, 'state_dtcm_sec_mem.dat'),
    # System TCM_CM7, 512KByte
    'dtcm_sec_ns' : MemoryRange(0x20400000, 0x80000, 'state_dtcm_sec_ns_mem.dat'),
    # OCRAM, 768KByte
    'ocram' : MemoryRange(0x30480000, 0xC0000, 'state_ocram_mem.dat'),
    # OCRAM, 768KByte
    'ocram_ns' : MemoryRange(0x20480000, 0xC0000, 'state_ocram_ns_mem.dat'),

    # FLASH, 64KByte / 512MByte
    'flash': MemoryRange(0x00000000, 0x20000000, 'state_flash_mem.dat', True, 0x10000),

    # SEMC0 SDRAM, 1.5GByte
    'semc0_sdram' : MemoryRange(0x80000000, 0x60000000, 'state_semc0_mem.dat'),

    # FlexSPI1 RAM, 256MByte
    'flexspi1_ram' : MemoryRange(0x38000000, 0x08000000, 'state_flexspi1_mem.dat'),
    # FlexSPI1 RAM, 256MByte
    'flexspi1_ram_ns' : MemoryRange(0x28000000, 0x08000000, 'state_flexspi1_ns_mem.dat'),
    # FlexSPI1 RAM, 256MByte
    'flexspi1_ram_a' : MemoryRange(0x12000000, 0x02000000, 'state_flexspi1_a_mem.dat'),
    # FlexSPI1 RAM, 256MByte
    'flexspi1_ram_a_ns' : MemoryRange(0x02000000, 0x02000000, 'state_flexspi1_a_ns_mem.dat'),

    # FlexSPI2 RAM, 256MByte
    'flexspi2_ram' : MemoryRange(0x14000000, 0x04000000, 'state_flexspi2_mem.dat'),
    # FlexSPI2 RAM, 256MByte
    'flexspi2_ram_ns' : MemoryRange(0x04000000, 0x04000000, 'state_flexspi2_ns_mem.dat'),
    # FlexSPI2 RAM, 256MByte
    'flexspi2_ram_a' : MemoryRange(0x32000000, 0x02000000, 'state_flexspi2_a_mem.dat'),
    # FlexSPI2 RAM, 256MByte
    'flexspi2_ram_a_ns' : MemoryRange(0x22000000, 0x02000000, 'state_flexspi2_a_ns_mem.dat')
}

reservedRegionDict = {   # new
    # OCRAM, 2MB
    'ram' : [0x30480000, 0x3048BFFF]
}

bootLogStart = 0x3048a000 # ROM 2.0 RC3
bootLogLength = 0x108

